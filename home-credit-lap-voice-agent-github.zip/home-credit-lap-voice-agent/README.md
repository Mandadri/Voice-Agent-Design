# Home Credit LAP AI Voice Agent

AI Voice Agent design for qualifying existing Home Credit customers for a pre-approved Loan Against Property (LAP) offer of up to ₹75,00,000.

## Objective

The agent should:
- Verify the customer identity.
- Present the LAP offer.
- Collect all 7 qualification details.
- Immediately disqualify when a mandatory eligibility condition fails.
- Detect existing-loan / EMI-reduction intent and route to a loan-transfer specialist.
- Handle busy customers and callback requests.
- Remember answers shared out of sequence and avoid asking them again.
- Hand off only after all required eligibility details are captured.

## Qualification Data Points

1. Property Type
2. Ownership Status
3. Original Property Documents Availability
4. Required Loan Amount
5. Occupation and Income Mode
6. Property Market Value
7. Preferred Loan Tenure

## Eligibility Rules

- Property must be Residential, Commercial, or Industrial.
- Agricultural property is not eligible.
- Sole and Joint ownership are both eligible.
- Original property documents must be available.
- Loan amount must be ₹75 lakh or below.
- Salaried and Self-Employed customers are eligible.
- Income must be received through bank; cash income is not eligible.
- Tenure must be between 3 and 15 years.
- Existing property loan / EMI reduction intent triggers loan-transfer routing.

## Repository Structure

```text
home-credit-lap-voice-agent/
├── README.md
├── prompts/
│   ├── system_prompt.md
│   └── system_prompt.txt
├── docs/
│   ├── conversation_flow.md
│   ├── eligibility_logic.md
│   └── submission_checklist.md
├── tests/
│   ├── test_scenarios.md
│   └── sample_call_transcripts.md
└── config/
    └── variables.json
```

## Platform Setup

Use Retell AI, Bolna, or a similar voice-agent platform.

1. Create a new voice agent.
2. Paste `prompts/system_prompt.txt` into the system/instruction prompt.
3. Configure the required variables.
4. Select a professional voice matching `agent_gender`.
5. Test all scenarios in `tests/test_scenarios.md`.
6. Save the public call recording and transcript link.
7. Submit the system prompt plus the public recording/log link.

## Required Dynamic Variables

- `company_name`
- `customer_name`
- `agent_name`
- `agent_gender`
- `current_date`
- `current_day`
- `current_time`
- `additional_context_from_rag`
- `language_to_speak`
- `conversation_history`
- `customer_utterance`

## Suggested GitHub Repository Name

`home-credit-lap-ai-voice-agent`

## Submission

Replace these placeholders after testing:

- **Voice Platform:** Retell AI / Bolna / Other
- **Public Call Recording:** `<ADD_PUBLIC_LINK>`
- **Public Transcript / Call Log:** `<ADD_PUBLIC_LINK>`
