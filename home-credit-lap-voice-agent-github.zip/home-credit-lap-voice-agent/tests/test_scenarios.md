# Test Scenarios

## Test 1 — Fully Eligible Customer

Customer:
- Residential flat
- Sole owner
- Original documents available
- ₹40 lakh required
- Salaried
- Income through bank
- Property value ₹80 lakh
- 10-year tenure

Expected:
- Complete all qualification questions.
- Mark as preliminarily qualified.
- Inform customer that a senior loan expert will call.

---

## Test 2 — Agricultural Property

Customer:
"I own agricultural land."

Expected:
- Immediately inform the customer that agricultural property is not eligible.
- End the qualification call.
- Do not ask remaining questions.

---

## Test 3 — No Original Documents

Customer:
"I only have photocopies. Originals are not available."

Expected:
- Disqualify politely.
- End call.

---

## Test 4 — Cash Income

Customer:
"I run a business and mostly receive my income in cash."

Expected:
- Disqualify.
- Explain bank-received income is required.
- End call.

---

## Test 5 — Loan Above ₹75 Lakh

Customer:
"I need ₹90 lakh."

Expected:
- Explain maximum available under this offer is ₹75 lakh.
- Ask whether customer wishes to continue with ₹75 lakh.
- Continue if accepted.
- End politely if declined.

---

## Test 6 — Existing Property Loan

Customer:
"I already have a home loan against this property. Can you reduce my EMI?"

Expected:
- Stop fresh-loan qualification.
- Inform customer that a loan-transfer specialist will contact them.
- End call.

---

## Test 7 — Busy Customer

Customer:
"I'm in a meeting. Call me tomorrow at 11."

Expected:
- Capture callback preference.
- Confirm callback.
- End call without qualification.

---

## Test 8 — Out-of-Order Answers

Customer:
"I have a commercial office jointly with my brother, documents are ready, and I'm looking for ₹60 lakh."

Expected:
Capture:
- Commercial
- Joint ownership
- Original documents available
- ₹60 lakh

Then ask the next unanswered field: occupation.

---

## Test 9 — Invalid Tenure, Customer Corrects

Customer:
"I want 20 years."

Agent:
Explain allowed tenure is 3–15 years.

Customer:
"Okay, make it 15 years."

Expected:
- Capture 15 years.
- Continue qualification.

---

## Test 10 — Missing Field Before Handoff

Customer has answered everything except market value.

Expected:
- Do not hand off yet.
- Ask property market value.
- Only then complete preliminary qualification.

---

## Test 11 — Interest Rate Question

Customer:
"What interest rate will I get?"

Expected:
- Do not invent a rate.
- Explain exact rate is provided by senior loan expert based on final profile/property assessment.
- Resume qualification.

---

## Test 12 — Customer Corrects Earlier Answer

Customer initially says:
"Residential."

Later:
"Sorry, it is agricultural land."

Expected:
- Replace the earlier property type.
- Apply agricultural disqualification.
- End call.
