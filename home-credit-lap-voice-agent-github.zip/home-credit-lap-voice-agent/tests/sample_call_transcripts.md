# Sample Call Transcripts

## Sample 1 — Qualified Lead

**Agent:** Hello, may I speak with Rahul?

**Customer:** Yes, speaking.

**Agent:** Thank you, Rahul. I’m Aisha calling on behalf of Home Credit. As a valued customer, you may be eligible for a special Loan Against Property offer of up to ₹75 lakh. I just need to check a few basic details to see whether the offer may fit your profile. Is this a good time?

**Customer:** Yes.

**Agent:** Great. What type of property would you like to use — residential, commercial, or industrial?

**Customer:** Residential flat.

**Agent:** Is the flat solely in your name or jointly owned?

**Customer:** Jointly with my wife.

**Agent:** Thank you. Do you have the original property documents available for verification?

**Customer:** Yes.

**Agent:** Approximately how much loan amount are you looking for?

**Customer:** Around ₹45 lakh.

**Agent:** Are you salaried or self-employed?

**Customer:** Salaried. My salary comes to my bank account.

**Agent:** Got it. What would you estimate the current market value of the property to be?

**Customer:** About ₹90 lakh.

**Agent:** And for how many years would you prefer to repay the loan?

**Customer:** 10 years.

**Agent:** Thank you. Based on the details you’ve shared, you meet the preliminary criteria for this offer. A senior loan expert will contact you shortly to discuss the next steps and provide the exact interest-rate and application details.

---

## Sample 2 — Disqualified for Cash Income

**Agent:** Are you salaried or self-employed?

**Customer:** I run my own business.

**Agent:** And is your regular income received through a bank account or mainly in cash?

**Customer:** Mostly cash.

**Agent:** Thank you for confirming. For this offer, the income needs to be received through a bank account, so we won’t be able to proceed with this specific offer at present. Thank you for your time.

---

## Sample 3 — Transfer Case

**Customer:** I already have a loan on this property. I mainly want to reduce my EMI.

**Agent:** Thank you for sharing that. Since this is related to an existing property loan, our loan-transfer specialist is better placed to assist you. A specialist will contact you shortly. Thank you for your time.
