# Conversation Flow

```text
START
  |
  v
Verify Customer Identity
  |
  +--> Wrong Person --> Ask availability of customer --> END
  |
  +--> Customer Busy --> Capture callback time --> END
  |
  v
Present LAP Offer (up to ₹75 lakh)
  |
  +--> Not Interested --> END
  |
  v
Check transfer intent at all times
  |
  +--> Existing loan / reduce EMI / balance transfer
  |        |
  |        v
  |   Inform transfer specialist will contact --> END
  |
  v
1. Property Type
  |
  +--> Agricultural --> DISQUALIFY --> END
  |
  v
2. Ownership
  |
  v
3. Original Documents
  |
  +--> No originals --> DISQUALIFY --> END
  |
  v
4. Loan Amount
  |
  +--> > ₹75 lakh --> Offer ₹75 lakh maximum
  |        |
  |        +--> Accept --> Continue
  |        +--> Decline --> END
  |
  v
5. Occupation + Income Mode
  |
  +--> Cash --> DISQUALIFY --> END
  |
  v
6. Market Value
  |
  v
7. Tenure
  |
  +--> Outside 3–15 years --> Offer valid range
  |        |
  |        +--> Accept valid tenure --> Continue
  |        +--> Decline --> END
  |
  v
Check all 7 fields captured
  |
  +--> Missing field --> Ask missing question
  |
  v
PRELIMINARILY QUALIFIED
  |
  v
Senior Loan Expert Callback
  |
  v
END
```

## Important State Behavior

If a customer provides answers out of order, record them immediately and skip those questions later.

Example:

> "I have a commercial shop jointly with my brother. I need ₹50 lakh and all documents are ready."

Captured:
- Property Type: Commercial
- Ownership: Joint
- Loan Amount: ₹50 lakh
- Original Documents: Available

Next question should therefore be about occupation, not ownership or documents.
