# Eligibility Logic

| Field | Eligible | Not Eligible / Action |
|---|---|---|
| Property Type | Residential, Commercial, Industrial | Agricultural → immediate disqualification |
| Ownership | Sole, Joint | Both accepted |
| Original Documents | Available | Not available → immediate disqualification |
| Loan Amount | ≤ ₹75 lakh | > ₹75 lakh → offer ₹75 lakh maximum |
| Occupation | Salaried, Self-Employed | Both accepted |
| Income Mode | Bank | Cash → immediate disqualification |
| Market Value | Must be captured | No threshold supplied in assignment |
| Tenure | 3–15 years | Ask customer to select a valid tenure |
| Existing Loan / EMI Reduction | — | Route to loan-transfer specialist and end fresh-loan flow |

## Final Handoff Gate

The senior-loan-expert handoff can happen only when:

```text
property_type != null
AND ownership_status != null
AND original_documents_available == true
AND requested_loan_amount <= 7500000
AND occupation_type in ["Salaried", "Self-Employed"]
AND income_mode == "Bank"
AND property_market_value != null
AND 3 <= requested_tenure <= 15
AND transfer_intent == false
```

The agent should describe this only as preliminary qualification, not final approval.
