# Submission Checklist

## Before Testing

- [ ] Create an agent on Retell AI, Bolna, or similar.
- [ ] Paste `prompts/system_prompt.txt`.
- [ ] Configure all required runtime variables.
- [ ] Select a professional voice.
- [ ] Ensure the voice matches `agent_gender`.
- [ ] Select English or Hindi based on `language_to_speak`.

## Required Testing

- [ ] Fully eligible customer.
- [ ] Agricultural property.
- [ ] Missing original documents.
- [ ] Cash income.
- [ ] Loan request above ₹75 lakh.
- [ ] Existing property loan / EMI reduction.
- [ ] Busy customer / callback.
- [ ] Out-of-order information.
- [ ] Invalid tenure corrected by customer.
- [ ] Missing qualification item before handoff.
- [ ] Interest-rate question.
- [ ] Customer correction of an earlier answer.

## Final Submission

Include:

1. System Prompt text.
2. Voice platform used.
3. Public call recording URL.
4. Public call transcript / call-log URL.

### Submission Template

```text
Candidate Name: ____________________

Assignment:
Home Credit Loan Against Property AI Voice Agent

Platform Used:
____________________

System Prompt:
GitHub: ____________________

Public Call Recording:
____________________

Public Transcript / Call Logs:
____________________
```
